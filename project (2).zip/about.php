 <?php 
 Echo "<html>";

Echo
"<h1 style='text-align:center'>asdfghjklmnopqrstuvwxyz</h1>";
//your php code here
Print
"<h3 style='text-align:center;color:green;'> <br>         zyxxdkfugekvfjvfivfkvf!                    </h3>";
 
?>