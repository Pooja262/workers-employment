 <?php 
 Echo "<html>";
Echo
"<title>HTML With PHP</title>";
Echo
"<b>My Example</b>";
//your php code here
Print
"<i>Print works too!</i>";
 
?>