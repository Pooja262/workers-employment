<html>
<head>
<title> WORKERS EMPLOYEMENT</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<h1 style='text-align:center'>WORKERS EMPLOYEMENT</h1><br><br><br><br><br>
<h3 style='text-align:center;color:white'>WELCOME TO THE SIGNUP PAGE<h3>

<div class="container">
<div class="login-box">
<div class="row">

<div class="col-md-6  login-right">
<h2> REGISTER</h2>
<form action="registration.php" method="post">
<div class="form-group">
<label>username</label>
<input type="text" name="user" class="form-control" required>
</div>
<div class="form-group">
<label>password</label>
<input type="password" name="password" class="form-control" required>
</div>
<button type="submit"  class="btn btn-primary">REGISTER</button>

</form>
</div>
</div>
</div>
</div>
</body>
</html>